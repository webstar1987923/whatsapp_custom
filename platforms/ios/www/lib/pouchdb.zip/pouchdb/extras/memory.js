'use strict';

module.exports = require('../lib/plugins/memory');